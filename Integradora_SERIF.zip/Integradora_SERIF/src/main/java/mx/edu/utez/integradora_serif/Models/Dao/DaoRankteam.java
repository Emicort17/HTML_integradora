package mx.edu.utez.integradora_serif.Models.Dao;

import mx.edu.utez.integradora_serif.Models.Objetos.RankTeam;
import mx.edu.utez.integradora_serif.Models.Objetos.Team;
import mx.edu.utez.integradora_serif.Utils.MySQLConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
public class DaoRankteam implements DaoRepository<RankTeam> {

    private Connection conn;
    private PreparedStatement pstm;
    private ResultSet rs;

    @Override
    public List<RankTeam> findAll() {
        List<RankTeam> rankTeams = new ArrayList<>();

        String query = "SELECT rt.*, t.* FROM RANK_TEAMS rt LEFT JOIN TEAMS t on t.Id_team = rt.fk_team ORDER BY Clasification ASC;";

        try { conn = new MySQLConnection().connect();
            pstm = conn.prepareStatement(query);
            rs = pstm.executeQuery();
            while (rs.next()) {
                RankTeam rankTeam = new RankTeam();
                rankTeam.setIdRank(rs.getInt("Id_rank"));
                rankTeam.setPoints(rs.getInt("Points"));
                rankTeam.setDraws(rs.getInt("Draws"));
                rankTeam.setWins(rs.getInt("Wins"));
                rankTeam.setLoses(rs.getInt("Loses"));
                rankTeam.setGoalDifference(rs.getInt("Goal_difference"));
                rankTeam.setGoalsScored(rs.getInt("Goals_scored"));
                rankTeam.setGoalsAgainst(rs.getInt("Goals_against"));
                rankTeam.setClasification(rs.getInt("Clasification"));
                rankTeam.setIdteam(rs.getInt("fk_team"));
                Team team = new Team();
                team.setId(rs.getInt("Id_team"));
                team.setName(rs.getString("Name_team"));
                team.setMembers(rs.getInt("Members"));
                team.setFile(rs.getString("image_data"));
                rankTeam.setTeam(team);

                rankTeams.add(rankTeam);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rankTeams;
    }

    @Override
    public RankTeam findOne(int id) {
        try {
            conn = new MySQLConnection().connect();

            String query = "SELECT * FROM RANK_TEAMS WHERE Id_rank = ?";
            pstm = conn.prepareStatement(query);
            pstm.setInt(1, id);
            rs = pstm.executeQuery();
            if (rs.next()) {
                RankTeam rankTeam = new RankTeam();
                rankTeam.setIdRank(rs.getInt("Id_rank"));
                rankTeam.setDraws(rs.getInt("Draws"));
                rankTeam.setWins(rs.getInt("Wins"));
                rankTeam.setLoses(rs.getInt("Loses"));
                rankTeam.setGoalDifference(rs.getInt("Goal_difference"));
                rankTeam.setGoalsScored(rs.getInt("Goals_scored"));
                rankTeam.setGoalsAgainst(rs.getInt("Goals_against"));
                rankTeam.setClasification(rs.getInt("Clasification"));
                rankTeam.setIdteam(rs.getInt("fk_team"));
                return rankTeam;
            }
        } catch (SQLException e) {
            Logger.getLogger(RankTeam.class.getName()).log(Level.SEVERE, "Error findOne: " + e.getMessage());
        } finally {
            closeResources();
        }
        return null;
    }


    @Override
    public boolean save(RankTeam rankTeam) {
        String query = "INSERT INTO RANK_TEAMS (Draws, Wins, Loses, Goal_difference, Goals_scored, Goals_against, Clasification, fk_team) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement pstm = conn.prepareStatement(query)) {
            pstm.setInt(1, rankTeam.getDraws());
            pstm.setInt(2, rankTeam.getWins());
            pstm.setInt(3, rankTeam.getLoses());
            pstm.setInt(4, rankTeam.getGoalDifference());
            pstm.setInt(5, rankTeam.getGoalsScored());
            pstm.setInt(6, rankTeam.getGoalsAgainst());
            pstm.setInt(7, rankTeam.getClasification());
            pstm.setInt(8, rankTeam.getIdteam());

            int rowsAffected = pstm.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean update(RankTeam rankTeam) {
        String query = "UPDATE RANK_TEAMS SET Draws = ?, Wins = ?, Loses = ?, Goal_difference = ?, Goals_scored = ?, Goals_against = ?, Clasification = ?, fk_team = ? WHERE Id_rank = ?";
        try (PreparedStatement pstm = conn.prepareStatement(query)) {
            pstm.setInt(1, rankTeam.getDraws());
            pstm.setInt(2, rankTeam.getWins());
            pstm.setInt(3, rankTeam.getLoses());
            pstm.setInt(4, rankTeam.getGoalDifference());
            pstm.setInt(5, rankTeam.getGoalsScored());
            pstm.setInt(6, rankTeam.getGoalsAgainst());
            pstm.setInt(7, rankTeam.getClasification());
            pstm.setInt(8, rankTeam.getIdteam());
            pstm.setInt(9, rankTeam.getIdRank());

            int rowsAffected = pstm.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean delete(int id) {
        String query = "DELETE FROM RANK_TEAMS WHERE Id_rank = ?";
        try (PreparedStatement pstm = conn.prepareStatement(query)) {
            pstm.setInt(1, id);
            int rowsAffected = pstm.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }


    private void closeResources() {
        try {
            if (rs != null) {
                rs.close();
            }
            if (pstm != null) {
                pstm.close();
            }
            if (conn != null) {
                conn.close();
            }
        } catch (SQLException e) {
            Logger.getLogger(Team.class.getName()).log(Level.SEVERE, "Error closing resources: " + e.getMessage());
        }
    }

}

package mx.edu.utez.integradora_serif.Models.Dao;

import mx.edu.utez.integradora_serif.Models.Objetos.Matchday;
import mx.edu.utez.integradora_serif.Models.Objetos.Team;
import mx.edu.utez.integradora_serif.Utils.MySQLConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DaoMatchday implements DaoRepository<Matchday> {
    private Connection conn;
    private PreparedStatement pstm;
    private ResultSet rs;



    public List<Matchday> findAllMatchdaysWithTeams() {
        List<Matchday> matchdays = new ArrayList<>();
        try {
            conn = new MySQLConnection().connect();

            String query = "SELECT \n" +
                    "    m.Id_matchday,\n" +
                    "    m.Match_field,\n" +
                    "    m.Starthour,\n" +
                    "    m.Endhour,\n" +
                    "    m.Date_match,\n" +
                    "    \n" +
                    "    tLocal.Id_team AS local_team_id,\n" +
                    "    tLocal.Name_team AS local_team_name,\n" +
                    "    tLocal.Members AS local_team_members,\n" +
                    "    tLocal.image_data AS local_team_image,\n" +
                    "\n" +
                    "    tVisit.Id_team AS visit_team_id,\n" +
                    "    tVisit.Name_team AS visit_team_name,\n" +
                    "    tVisit.Members AS visit_team_members,\n" +
                    "    tVisit.image_data AS visit_team_image\n" +
                    "\n" +
                    "FROM MATCHDAY m\n" +
                    "LEFT JOIN TEAMS tLocal ON m.Teamlocal = tLocal.Id_team\n" +
                    "LEFT JOIN TEAMS tVisit ON m.Teamvisit = tVisit.Id_team;";

            pstm = conn.prepareStatement(query);
            rs = pstm.executeQuery();
            while (rs.next()) {
                Matchday matchday = new Matchday();

                matchday.setId(rs.getInt("Id_matchday"));
                matchday.setMatch_field(rs.getString("Match_field"));
                matchday.setStarthour(rs.getTime("Starthour"));
                matchday.setEndhour(rs.getTime("Endhour"));
                matchday.setDate_match(rs.getDate("Date_match"));
                Team visit = new Team();
                visit.setId(rs.getInt("visit_team_id"));
                visit.setName(rs.getString("visit_team_name"));
                visit.setMembers(rs.getInt("visit_team_members"));
                visit.setFile(rs.getString("visit_team_image"));
                matchday.setVisitante(visit);
                Team local = new Team();
                local.setId(rs.getInt("local_team_id"));
                local.setName(rs.getString("local_team_name"));
                local.setMembers(rs.getInt("local_team_members"));
                local.setFile(rs.getString("local_team_image"));
                matchday.setLocal(local);

                matchdays.add(matchday);
            }
        } catch (SQLException e) {
            Logger.getLogger(Matchday.class.getName()).log(Level.SEVERE, "Error findAllMatchdaysWithTeams: " + e.getMessage());
        } finally {
            closeResources();
        }
        return matchdays;
    }


    @Override
    public List<Matchday> findAll() {
        List<Matchday> matchdays = null;
        try {
            matchdays = new ArrayList<>();
            conn = new MySQLConnection().connect();

            String query =  "SELECT \n" +
                    "    m.Id_matchday,\n" +
                    "    m.Match_field,\n" +
                    "    m.Starthour,\n" +
                    "    m.Endhour,\n" +
                    "    m.Date_match,\n" +
                    "    \n" +
                    "    tLocal.Name_team AS local_team_name,\n" +
                    "    tLocal.image_data AS local_team_image,\n" +
                    "\n" +
                    "    tVisit.Name_team AS visit_team_name,\n" +
                    "    tVisit.image_data AS visit_team_image\n" +
                    "\n" +
                    "FROM MATCHDAY m\n" +
                    "LEFT JOIN TEAMS tLocal ON m.Teamlocal = tLocal.Id_team\n" +
                    "LEFT JOIN TEAMS tVisit ON m.Teamvisit = tVisit.Id_team;";
            pstm = conn.prepareStatement(query);
            rs = pstm.executeQuery();
            while (rs.next()){
                Matchday matchday = new Matchday();
                matchday.setId(rs.getInt("Id_matchday"));
                matchday.setMatch_field(rs.getString("Match_field"));
                matchday.setStarthour(rs.getTime("Starthour"));
                matchday.setEndhour(rs.getTime("Endhour"));
                matchday.setDate_match(rs.getDate("Date_match"));
                Team visit = new Team();
                visit.setName(rs.getString("visit_team_name"));
                visit.setFile(rs.getString("visit_team_image"));
                matchday.setVisitante(visit);
                Team local = new Team();
                local.setName(rs.getString("local_team_name"));
                local.setFile(rs.getString("local_team_image"));
                matchday.setLocal(local);
                matchdays.add(matchday);
            }
        } catch (SQLException e) {
            Logger.getLogger(Matchday.class.getName()).log(Level.SEVERE, "Error findAll: " + e.getMessage());
        }finally {
            closeResources();
        }
        return matchdays;
    }

    @Override
    public Matchday findOne(int id) {
        try {
            conn = new MySQLConnection().connect();
            String query = "SELECT * FROM MATCHDAY WHERE Id_matchday = ?;";
            pstm = conn.prepareStatement(query);
            pstm.setInt(1, id);
            rs = pstm.executeQuery();
            Matchday matchday = new Matchday();
            if(rs.next()){
                matchday.setId(rs.getInt("Id_matchday"));
                matchday.setMatch_field(rs.getString("Match_field"));
                matchday.setStarthour(rs.getTime("Starthour"));
                matchday.setEndhour(rs.getTime("Endhour"));
                matchday.setDate_match(rs.getDate("Date_match"));
                matchday.setLocal(new DaoTeam().findOne(rs.getInt("Teamlocal")));
                matchday.setVisitante(new DaoTeam().findOne(rs.getInt("Teamvisit")));

            }
            return matchday;
        } catch (SQLException e) {
            Logger.getLogger(Matchday.class.getName()).log(Level.SEVERE, "Error findOne: " + e.getMessage());
        }finally {
            closeResources();
        }
        return null;
    }

    @Override
    public boolean save(Matchday matchday) {
        try{
            conn = new MySQLConnection().connect();
            String query = "INSERT INTO MATCHDAY (Match_field, Starthour, Endhour, Date_match, Teamlocal, Teamvisit) VALUES (?, ?, ? , ?, ?, ?);";
            pstm = conn.prepareStatement(query);
            pstm.setString(1, matchday.getMatch_field());
            pstm.setTime(2, matchday.getStarthour());
            pstm.setTime(3, matchday.getEndhour());
            pstm.setDate(4, matchday.getDate_match());
            pstm.setInt(5, matchday.getLocal().getId());
            pstm.setInt(6, matchday.getVisitante().getId());
            return pstm.executeUpdate() > 0;

        } catch (SQLException e) {
            Logger.getLogger(Matchday.class.getName()).log(Level.SEVERE, "Error save: " + e.getMessage());
        }finally {
            closeResources();
        }
        return false;
    }

    @Override
    public boolean update(Matchday matchday){
        return false;
    }

    public boolean updateMatch(Matchday matchday, int teamLocalId, int teamVisitId) {
        try{
            conn = new MySQLConnection().connect();
            String query = "UPDATE MATCHDAY SET Match_field = ?, Starthour = ?, Endhour = ?, Date_match=?, Teamlocal = ?, Teamvisit= ? WHERE Id_matchday = ?;";
            pstm=conn.prepareStatement(query);
            pstm.setString(1, matchday.getMatch_field());
            pstm.setTime(2, matchday.getStarthour());
            pstm.setTime(3, matchday.getEndhour());
            pstm.setDate(4, matchday.getDate_match());
            pstm.setInt(5, teamLocalId);
            pstm.setInt(6, teamVisitId);
            pstm.setInt(7,matchday.getId());
            return pstm.executeUpdate() > 0;
        } catch (SQLException e) {
            Logger.getLogger(Matchday.class.getName()).log(Level.SEVERE, "Error update: " + e.getMessage());
        }finally {
            closeResources();
        }
        return false;
    }

    @Override
    public boolean delete(int id) {
        try{
            conn = new MySQLConnection().connect();

            String query = "DELETE FROM MATCHDAY WHERE Id_team = ?;";
            pstm = conn.prepareStatement(query);
            pstm.setInt(1, id);
            return pstm.executeUpdate() > 0;

        } catch (SQLException e) {
            Logger.getLogger(Matchday.class.getName()).log(Level.SEVERE, "Error delete: " + e.getMessage());

        }finally {
            closeResources();
        }
        return false;
    }

    private void closeResources() {
        try {
            if (rs != null) {
                rs.close();
            }
            if (pstm != null) {
                pstm.close();
            }
            if (conn != null) {
                conn.close();
            }
        } catch (SQLException e) {
            Logger.getLogger(Team.class.getName()).log(Level.SEVERE, "Error closing resources: " + e.getMessage());
        }
    }

}

package mx.edu.utez.integradora_serif.Controllers.Representatives;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import mx.edu.utez.integradora_serif.Models.Objetos.Representative;
import mx.edu.utez.integradora_serif.Models.Dao.DaoRepresentative;
import mx.edu.utez.integradora_serif.Models.Dao.DaoTeam;

import mx.edu.utez.integradora_serif.Models.Objetos.Team;

import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.List;

@WebServlet(name = "ServletRepresentative",
        urlPatterns = {"/representative/representatives",
                "/representative/create",
                "/representative/save",
                "/representative/modify",
                "/representative/update",
                "/representative/delete"
        })
    public class ServletRep extends HttpServlet {

        private String action;
        private String redirect = "/representative/representatives";
        Representative representative;
        private int id;
        private String name;
        private String lastName;
        private String lastName2;
        private String phoneNumber;
        private String username;
        private String password;
        private int teamId;

        @Override
        protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
            req.setCharacterEncoding("UTF-8");
            action = req.getServletPath();

            switch (action) {
                case "/representative/representatives":
                    List<Representative> representatives = new DaoRepresentative().findAll();
                    System.out.println("datos,," + representatives);
                    req.setAttribute("representatives", representatives);
                    req.getRequestDispatcher("/views/Admin/Representative.jsp").forward(req, resp);
                    break;
                case "/representative/modify":
                    int representativeId = Integer.parseInt(req.getParameter("Id_representative"));
                    Representative representativeToModify = new DaoRepresentative().findOne(representativeId);
                    System.out.println(representativeToModify);
                    if (representativeToModify != null) {
                        req.setAttribute("representative", representativeToModify);
                        List<Team> equipos = new DaoTeam().findAll();
                        req.setAttribute("equipos", equipos);
                        req.getRequestDispatcher("/views/Admin/RepresentativosEditar.jsp").forward(req, resp);
                    } else {
                        resp.sendError(HttpServletResponse.SC_NOT_FOUND);
                    }
                    break;

                case "/representative/create":
                    resp.sendRedirect("/views/Admin/RegistroRepresentative.jsp");
                    break;
                default:
                    resp.sendError(HttpServletResponse.SC_NOT_FOUND);

            }
        }

        @Override
        protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
            String action = req.getServletPath();

            switch (action) {
                case "/representives/save":
                    String newName = req.getParameter("name");
                    int newMembers = Integer.parseInt(req.getParameter("members"));


                    Team newTeam = new Team(0, newName, newMembers);
                    boolean result = new DaoTeam().save(newTeam);
                    if (result) {
                        resp.sendRedirect(req.getContextPath() + "/equipo/equipos");
                    } else {
                        req.setAttribute("error", "Error al registrar el equipo");
                        req.getRequestDispatcher("/views/Representatives/RegistroEquipo.jsp").forward(req, resp);
                    }
                    break;
                case "/equipo/update":
                    int teamIdToUpdate = Integer.parseInt(req.getParameter("id"));
                    String updatedName = req.getParameter("name");
                    int updatedMembers = Integer.parseInt(req.getParameter("members"));

                    Team updatedTeam = new Team(teamIdToUpdate, updatedName, updatedMembers);
                    boolean updateResult = new DaoTeam().update(updatedTeam);
                    if (updateResult) {
                        resp.sendRedirect(req.getContextPath() + "/equipo/equipos");
                    } else {
                        req.setAttribute("error", "Error al actualizar el equipo");
                        req.getRequestDispatcher("/views/User/Equipo.jsp").forward(req, resp);
                    }
                    break;

                case "/equipo/delete":
                    id = Integer.parseInt(req.getParameter("Id_team"));
                    if ((new DaoTeam()).delete( Integer.parseInt(String.valueOf(id)))) {
                        redirect = "/equipo/equipos?result= true&message=" + URLEncoder.encode("Equipo eliminado de forma exitosa", StandardCharsets.UTF_8);
                    } else {
                        redirect = "/equipo/equipos?result= false&message=" + URLEncoder.encode("Error al realizar la acción", StandardCharsets.UTF_8);
                    }
                    break;


                default:
                    resp.sendError(HttpServletResponse.SC_NOT_FOUND);
            }
        }

    }

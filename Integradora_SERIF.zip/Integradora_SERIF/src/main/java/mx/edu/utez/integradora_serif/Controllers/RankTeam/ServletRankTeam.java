package mx.edu.utez.integradora_serif.Controllers.RankTeam;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import mx.edu.utez.integradora_serif.Models.Dao.DaoRankteam;
import mx.edu.utez.integradora_serif.Models.Objetos.RankTeam;

import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

import java.util.List;

@WebServlet(name = "ServletRankTeam", urlPatterns = {
        "/rankteam/rankteams",
        "/rankteam/modify",
        "/rankteam/create",
        "/rankteam/update",
        "/rankteam/delete",
})
public class ServletRankTeam extends HttpServlet {
    private String action;
    private String redirect = "/rankteam/rankteams";
    RankTeam rankTeam;
    private int id;
    private int draws;
    private int wins;
    private int points;
    private int loses;
    private int goalDifference;
    private int goalsScored;
    private int goalsAgainst;
    private int clasification;
    private int fkTeam;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        this.action = req.getServletPath();
        switch (this.action) {
            case "/rankteam/rankteams":
                List<RankTeam> rankTeams = new DaoRankteam().findAll();
                req.setAttribute("rankTeams", rankTeams);
                System.out.println("Rankingteams:"+rankTeams.toString());
                redirect = "/views/Jerry/RankTeams.jsp";
                break;
            case "/rankteam/modify":
                this.id = Integer.parseInt(req.getParameter("Id_rank"));
                this.rankTeam = (new DaoRankteam()).findOne(this.id != 0 ? Integer.parseInt(String.valueOf(this.id)) : 0);
                if (this.rankTeam != null) {
                    req.setAttribute("Draws", draws);
                    req.setAttribute("Wins", wins);

                } else {
                    break;
                }
            default:
                System.out.println(this.action);
        }
        req.getRequestDispatcher(this.redirect).forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html");
        this.action = req.getServletPath();
        switch (this.action) {
            case "/rankteam/delete":
                this.id = Integer.parseInt(req.getParameter("Id_rank"));
                if ((new DaoRankteam()).delete(Integer.parseInt(String.valueOf(this.id)))) {
                    this.redirect = "/rankteam/delete?result=true&message=" + URLEncoder.encode("Registro eliminado exitosamente", StandardCharsets.UTF_8);
                } else {
                    this.redirect = "/rankteam/delete?result=false&message=" + URLEncoder.encode("Error al realizar la acción", StandardCharsets.UTF_8);
                }
                break;
            case "/rankteam/update":
                this.id = Integer.parseInt("Id_rank");
                this.draws = Integer.parseInt(req.getParameter("Draws"));
                this.wins = Integer.parseInt(req.getParameter("Wins"));
                // ... y así sucesivamente para los demás atributos
                if ((new DaoRankteam()).update(this.rankTeam)) {
                    this.redirect = "/rankteam/update?result=true&message=" + URLEncoder.encode("Registro actualizado exitosamente", StandardCharsets.UTF_8);
                } else {
                    this.redirect = "/rankteam/update?result=false&message=" + URLEncoder.encode("Error al realizar la acción", StandardCharsets.UTF_8);
                }
        }
        String var10001 = req.getContextPath();
        resp.sendRedirect(var10001 + this.redirect);
    }
}

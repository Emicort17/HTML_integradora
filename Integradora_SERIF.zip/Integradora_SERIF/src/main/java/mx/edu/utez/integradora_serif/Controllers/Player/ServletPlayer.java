package mx.edu.utez.integradora_serif.Controllers.Player;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;
import mx.edu.utez.integradora_serif.Models.Dao.DaoPlayer;
import mx.edu.utez.integradora_serif.Models.Dao.DaoTeam;
import mx.edu.utez.integradora_serif.Models.Objetos.Player;
import mx.edu.utez.integradora_serif.Models.Objetos.Team;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.List;
@WebServlet(name = "ServeletPlayer", urlPatterns = {
        "/rep/jugador/jugadores", //dominio privado
        "/jugador/equipo", //dominio publico
        "/jugador/jugadores", //dominio publico
        "/jugador/jugador", //dominio publico
        "/jugador/save", //dominio privado
        "/jugador/create", //dominio privado
        "/jugador/modify", //dominio privado
        "/jugador/delete" //dominio privado
})
@MultipartConfig
public class ServletPlayer extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private String action;
    private String redirect;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        action = req.getServletPath();
        switch (action) {
            case "/rep/jugador/jugadores":
                List<Player> jugadores = (new DaoPlayer()).findAll();
                req.setAttribute("jugadores", jugadores);
                redirect = "/views/Representatives/Jugadores.jsp";
                break;

            case "/jugador/jugador":
                redirect = "/views/Representatives/PlayerCredentialForm.jsp";
            break;
            case "/jugador/create":
                List<Team> equipos = new DaoTeam().findAll();
                req.setAttribute("equipos", equipos);
                redirect = "/views/Representatives/CrearJugador.jsp";
                break;
            case "/jugador/modify":
                int id = Integer.parseInt(req.getParameter("Id"));
                System.out.println(id);
                Player player = new DaoPlayer().findOne(id);
                req.setAttribute("player", player);
                redirect= "/views/Representatives/Playerupd.jsp";
                break;

            case "/jugador/equipo":
                int id_eq  = Integer.parseInt(req.getParameter("Id_team"));
                System.out.println(id_eq);
                List<Player> players = new DaoPlayer().PlayerbyTeam(id_eq);
                System.out.println("jugadores:" + players);
                req.setAttribute("players", players);
                redirect = "/views/Jerry/EquipoTeam.jsp";
                break;
            case "/jugador/delete":
                int deleteId = Integer.parseInt(req.getParameter("Id"));
                System.out.println("ID QUE SE ELIMINA:" + deleteId);
                boolean isDeleted = new DaoPlayer().delete(deleteId);
                System.out.println(isDeleted);
                if (isDeleted) {
                    req.setAttribute("successMessage", "Jugador eliminado con éxito");
                    String redirect = "/rep/jugador/jugadores"; // Define la variable redirect
                    // Utiliza RequestDispatcher para redirigir internamente sin cambiar la URL
                    RequestDispatcher dispatcher = req.getRequestDispatcher(redirect);
                    dispatcher.forward(req, resp);
                } else {
                    // Manejar caso de no eliminación
                    req.setAttribute("errorMessage", "No se pudo eliminar el jugador");
                    String redirect = "/rep/jugador/jugadores"; // Define la variable redirect
                    // Utiliza RequestDispatcher para redirigir internamente sin cambiar la URL
                    RequestDispatcher dispatcher = req.getRequestDispatcher(redirect);
                    dispatcher.forward(req, resp);
                }
                return;
        }
        req.getRequestDispatcher(redirect).forward(req, resp);
    }


    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html");
        action = req.getServletPath();
        switch (action) {
            case "/jugador/modify":
                // get params from Form
                int id = Integer.parseInt(req.getParameter("Id"));
                String name = req.getParameter("name");
                String surname = req.getParameter("Surname");
                String surname2 = req.getParameter("Surname2");
                String position = req.getParameter("Position");
                String dorsal = req.getParameter("Dorsal");
                int teamId = Integer.parseInt(req.getParameter("TeamId"));
                // Get current player
                DaoPlayer daoPlayer = new DaoPlayer();
                Player currentPlayer = daoPlayer.findOne(id);

                if (currentPlayer == null) {
                    req.setAttribute("errorMessage", "Jugador no encontrado para actualizar");
                    resp.sendRedirect("/jugador/modify?player=" + id + "&message="+URLEncoder.encode("Error  al realizar la acción", StandardCharsets.UTF_8));
                }
                Player playerToUpdate = new Player();
                playerToUpdate.setId(id);
                playerToUpdate.setName(name != null ? name : currentPlayer.getName());
                playerToUpdate.setSurname(surname != null ? surname : currentPlayer.getSurname());
                playerToUpdate.setSurname2(surname2 != null ? surname2 : currentPlayer.getSurname2());
                playerToUpdate.setPosition(position != null ? position : currentPlayer.getPosition());
                playerToUpdate.setDorsal(dorsal != null ? dorsal : currentPlayer.getDorsal());
                playerToUpdate.setTeamId(teamId != 0 ? teamId : currentPlayer.getTeamId());
                playerToUpdate.setFile(currentPlayer.getFile());

                boolean isSuccess = daoPlayer.update(playerToUpdate);
                System.out.println("isSuccess :" + isSuccess);
                if (isSuccess) {
                    req.setAttribute("successMessage", "Jugador actualizado con éxito");
                    resp.sendRedirect("/rep/jugador/jugadores?message=" + URLEncoder.encode("jugador actualizado correctamente", StandardCharsets.UTF_8));
                } else  {
                    req.setAttribute("errorMessage", "Jugador no encontrado para actualizar");
                    resp.sendRedirect("/jugador/modify?player=" + id + "&message=" + URLEncoder.encode("Error al realizar la acción", StandardCharsets.UTF_8));
                }
                return;
            case "/jugador/save":
                Part filePart = req.getPart("playerImage");
                String base64Image = convertToBase64(filePart);
                Player newPlayer = new Player();
                newPlayer.setFile(base64Image);
                newPlayer.setName(req.getParameter("name"));
                newPlayer.setSurname(req.getParameter("Surname"));
                newPlayer.setSurname2(req.getParameter("Surname2"));
                newPlayer.setPosition(req.getParameter("Position"));
                newPlayer.setDorsal(req.getParameter("Dorsal"));
                newPlayer.setTeamId(Integer.parseInt(req.getParameter("TeamId")));
                boolean Exito = (new DaoPlayer().save(newPlayer));
                System.out.println("isSuccess :" + Exito);
                if (Exito){
                    req.setAttribute("successMessage", "Jugador creado con éxito");
                    resp.sendRedirect("/rep/jugador/jugadores?message=" + URLEncoder.encode("jugador actualizado correctamente", StandardCharsets.UTF_8));
                    redirect = "/rep/jugador/jugadores";
                }else {
                    req.setAttribute("successMessage", "Jugador creado con éxito");
                    resp.sendRedirect("/rep/jugador/jugadores?message=" + URLEncoder.encode("jugador actualizado correctamente", StandardCharsets.UTF_8));
                }
                return;
        }
        req.getRequestDispatcher(redirect).forward(req, resp);
    }
    private String convertToBase64(Part filePart) throws IOException {
        InputStream inputStream = filePart.getInputStream();
        byte[] bytes = new byte[(int) filePart.getSize()];
        inputStream.read(bytes, 0, bytes.length);
        inputStream.close();
        return Base64.getEncoder().encodeToString(bytes);
    }
}

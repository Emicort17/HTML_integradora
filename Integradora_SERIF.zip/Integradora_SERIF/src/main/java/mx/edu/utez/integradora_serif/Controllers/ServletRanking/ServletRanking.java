package mx.edu.utez.integradora_serif.Controllers.ServletRanking;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

import mx.edu.utez.integradora_serif.Models.Dao.DaoPlayer;
import mx.edu.utez.integradora_serif.Models.Dao.DaoRanking;
import mx.edu.utez.integradora_serif.Models.Objetos.Player;
import mx.edu.utez.integradora_serif.Models.Objetos.RankingPlayer;

import java.io.IOException;
import java.io.InputStream;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.List;

@WebServlet(name = "ServletRanking", urlPatterns = {
        "/ranking/rankers",
        "/ranking/create",
        "/ranking/modify",
        "/ranking/delete"
})
public class ServletRanking extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private String action;
    private String redirect;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        action = req.getServletPath();
        switch (action) {
            case "/ranking/rankers":
                List<RankingPlayer> rankings = new DaoRanking().findAll();
                req.setAttribute("rankings", rankings);
                System.out.println("Datos,"+ rankings.toString());
                redirect = "/views/Jerry/Ranking.jsp";
                break;
            case "/ranking/create":
                redirect = "/views/Ranking/CreateRanking.jsp";
                break;

        }
        req.getRequestDispatcher(redirect).forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html");
        action = req.getServletPath();
        switch (action) {
            case "/ranking/create":
                int redCard = Integer.parseInt(req.getParameter("RedCard"));
                int yellowCard = Integer.parseInt(req.getParameter("YellowCard"));
                int goals = Integer.parseInt(req.getParameter("Goals"));
                int assistances = Integer.parseInt(req.getParameter("Assistances"));
                int playerId = Integer.parseInt(req.getParameter("PlayerId"));

                RankingPlayer newRanking = new RankingPlayer();
                newRanking.setRedCard(redCard);
                newRanking.setYellowCard(yellowCard);
                newRanking.setGoals(goals);
                newRanking.setAssistances(assistances);
                newRanking.setPlayerId(playerId);

                new DaoRanking().save(newRanking);
                req.setAttribute("successMessage", "Clasificación creada con éxito");
                resp.sendRedirect("/ranking/list?message=" + URLEncoder.encode("Clasificación creada correctamente", StandardCharsets.UTF_8));
                break;

            // Agregar más casos según sea necesario
        }
    }

    // Agregar más métodos y funciones según sea necesario
}


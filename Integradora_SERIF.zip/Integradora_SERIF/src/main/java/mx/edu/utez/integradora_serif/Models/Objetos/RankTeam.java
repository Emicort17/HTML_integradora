package mx.edu.utez.integradora_serif.Models.Objetos;

public class RankTeam {
    private int idRank;
    private int points;
    private int draws;
    private int wins;
    private int loses;
    private int goalDifference;
    private int goalsScored;
    private int goalsAgainst;
    private int clasification;
    private int idteam;

    Team team;

    // Constructors, getters and setters

    public RankTeam() {
        // Default constructor
    }

    public RankTeam(int idRank,int points, int draws, int wins, int loses, int goalDifference, int goalsScored, int goalsAgainst, int clasification, int idteam, Team team) {
        this.idRank = idRank;
        this.points = points;
        this.draws = draws;
        this.wins = wins;
        this.loses = loses;
        this.goalDifference = goalDifference;
        this.goalsScored = goalsScored;
        this.goalsAgainst = goalsAgainst;
        this.clasification = clasification;
        this.idteam = idteam;
        this.team = team;
    }

    public int getIdteam() {
        return idteam;
    }

    public void setIdteam(int idteam) {
        this.idteam = idteam;
    }

    public int getIdRank() {
        return idRank;
    }

    public void setIdRank(int idRank) {
        this.idRank = idRank;
    }

    public int getPoints() {
        return points;
    }

    public void setPoints(int points) {
        this.points = points;
    }

    public int getDraws() {
        return draws;
    }

    public void setDraws(int draws) {
        this.draws = draws;
    }

    public int getWins() {
        return wins;
    }

    public void setWins(int wins) {
        this.wins = wins;
    }

    public int getLoses() {
        return loses;
    }

    public void setLoses(int loses) {
        this.loses = loses;
    }

    public int getGoalDifference() {
        return goalDifference;
    }

    public void setGoalDifference(int goalDifference) {
        this.goalDifference = goalDifference;
    }

    public int getGoalsScored() {
        return goalsScored;
    }

    public void setGoalsScored(int goalsScored) {
        this.goalsScored = goalsScored;
    }

    public int getGoalsAgainst() {
        return goalsAgainst;
    }

    public void setGoalsAgainst(int goalsAgainst) {
        this.goalsAgainst = goalsAgainst;
    }

    public int getClasification() {
        return clasification;
    }

    public void setClasification(int clasification) {
        this.clasification = clasification;
    }

    public Team getTeam() {
        return team;
    }

    public void setTeam(Team team) {
        this.team = team;
    }

    @Override
    public String toString() {
        return "RankTeam{" +
                "idRank=" + idRank +
                ", draws=" + draws +
                ", wins=" + wins +
                ", loses=" + loses +
                ", goalDifference=" + goalDifference +
                ", goalsScored=" + goalsScored +
                ", goalsAgainst=" + goalsAgainst +
                ", clasification=" + clasification +
                ", team=" + team +
                '}';
    }
}

package mx.edu.utez.integradora_serif.Models.Objetos;

import java.sql.Date;
import java.sql.Time;

public class Matchday {
    private int id;
    private String match_field;
    private Time starthour;
    private Time endhour;
    private Date date_match;

    Team visitante;
    Team local;
    public Matchday(){

    }

    public Matchday(int id, String match_field, Time starthour, Time endhour, Date date_match,Team local, Team visitante) {
        this.id = id;
        this.match_field = match_field;
        this.starthour = starthour;
        this.endhour = endhour;
        this.date_match = date_match;
        this.visitante = visitante;
        this.local = local;
    }

    public Matchday(int id, String match_field, Time starthour, Time endhour, Date date_match ) {
        this.id = id;
        this.match_field = match_field;
        this.starthour = starthour;
        this.endhour = endhour;
        this.date_match = date_match;

    }

    public Team getVisitante() {
        return visitante;
    }

    public void setVisitante(Team visitante) {
        this.visitante = visitante;
    }

    public Team getLocal() {
        return local;
    }

    public void setLocal(Team local) {
        this.local = local;
    }

    public int getId() {
        return id;
    }
    public Integer getMyId() {
        return Integer.valueOf(id);
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMatch_field() {
        return match_field;
    }

    public void setMatch_field(String match_field) {
        this.match_field = match_field;
    }

    public Time getStarthour() {
        return starthour;
    }

    public void setStarthour(Time starthour) {
        this.starthour = starthour;
    }

    public Time getEndhour() {
        return endhour;
    }

    public void setEndhour(Time endhour) {
        this.endhour = endhour;
    }

    public Date getDate_match() {
        return date_match;
    }

    public void setDate_match(Date date_match) {
        this.date_match = date_match;
    }


    @Override
    public String toString() {
        return "Matchday{" +
                "id=" + id +
                ", match_field='" + match_field + '\'' +
                ", starthour=" + starthour +
                ", endhour=" + endhour +
                ", date_match=" + date_match +
                ", visitante=" + visitante +
                ", local" + local +
                '}';
    }
}



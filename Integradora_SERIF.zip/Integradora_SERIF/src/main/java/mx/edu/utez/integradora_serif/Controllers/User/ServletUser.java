package mx.edu.utez.integradora_serif.Controllers.User;


import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import mx.edu.utez.integradora_serif.Models.User.DaoRepresentative;
import mx.edu.utez.integradora_serif.Models.User.Representative;
import mx.edu.utez.integradora_serif.Models.User.Representative;


import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@WebServlet(name = "ServletUser",
        urlPatterns = {"/page/inicio",
                "/page/logout",
                "/page/user/all",
                "/page/user/one",
                "/page/user/save",
                "/page/user/create",
                "/page/user/modify",
                "/page/user/update",
                "/api/user/enable-disabled"
        })
public class ServletUser extends HttpServlet {
    String action, redirect = "/User/index.jsp";
    Representative representative;
    HttpSession session;
    String id, username, password, teamId;
    String name, lastname, lastname2, phoneNumber;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        action = req.getServletPath();
        switch (action) {
            case "/page/inicio":
                redirect = "/views/User/index.jsp";
                break;
            case "/page/logout":
                session = req.getSession();
                session.invalidate();
                redirect = "/views/User/index.jsp";
                break;
        }
        req.getRequestDispatcher(redirect)
                .forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html");
        action = req.getServletPath();
        switch (action) {
            case "/api/auth":
                username = req.getParameter("username");
                password = req.getParameter("password");
                try {
                    representative = new DaoRepresentative().loadUserByUsernameAndPassword(username, password);
                    if (representative != null) {
                        session = req.getSession();
                        session.setAttribute("Representative", representative);
                    } else {
                        throw new Exception("Credentials mismatch");
                    }
                } catch (Exception e) {
                    redirect = "/api/auth?result=false&message=" + URLEncoder
                            .encode("Usuario y/o contraseña incorrecta",
                                    StandardCharsets.UTF_8);
                }
                break;
        }
        resp.sendRedirect(req.getContextPath()
                + redirect);
    }
}


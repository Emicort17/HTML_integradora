package mx.edu.utez.integradora_serif.Models.Objetos;


public class Team {

    private int id;
    private String name;
    private int members;
    private String file;

    public Team() {
    }
    public Team(String name) {
        this.name = name;
    }

    public Team(int id, String name, int members) {
        this.id = id;
        this.name = name;
        this.members = members;

    }
    public Team( String name, int members, String file) {
        this.name = name;
        this.members = members;

        this.file = file;
    }

    public String getFile() {
        return file;
    }

    public void setFile(String file) {
        this.file = file;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getMembers() {
        return members;
    }

    public void setMembers(int members) {
        this.members = members;
    }


    @Override
    public String toString() {
        return "Team{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", members=" + members +
                ", file='" + file + '\'' +
                '}';
    }
}

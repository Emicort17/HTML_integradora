package mx.edu.utez.integradora_serif.Controllers.Team;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;
import mx.edu.utez.integradora_serif.Models.Dao.DaoTeam;
import mx.edu.utez.integradora_serif.Models.Objetos.Team;


import java.io.IOException;
import java.io.InputStream;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.List;

@WebServlet(name = "ServletTeam",
        urlPatterns = {"/equipo/equipos",
                "/equipo/equipo",
                "/equipo/save",
                "/rep/equipo/create",
                "/equipo/modify",
                "/equipo/update",
                "/equipo/delete",
                "/rep/equipo/equipos"

        })
@MultipartConfig
public class ServletTeam extends HttpServlet{
    String action;
    String redirect = "/equipo/equipos";
    Team team;
    int id;
    String name;
    int members;
    String file;


    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        action = req.getServletPath();
        switch (action) {
            case "/equipo/equipos":
                List<Team> equipos = (new DaoTeam()).findAll();
                System.out.println(equipos.toString());
                req.setAttribute("teams", equipos);
                redirect = "/views/Jerry/Teams.jsp";
                break;
            case "/equipo/equipo":
                redirect = "/views/Representatives/Equipo.jsp";
                break;
            case "/rep/equipo/create":
                redirect = "/views/Representatives/RegistroEquipo.jsp";
                break;
            case "/equipo/update":
                id = Integer.parseInt(req.getParameter("Id_team"));
                team = (new DaoTeam()).findOne(this.id);
                if (team != null) {
                    req.setAttribute("team", team);
                    req.getRequestDispatcher("/views/Representatives/update.jsp").forward(req, resp);
                } else {
                    resp.sendRedirect("/equipo/equipos?result=false&message=" + URLEncoder.encode("Error al cargar datos de equipo para edición", StandardCharsets.UTF_8));
                }
                break;
            case "/equipo/modify":
                int id = Integer.parseInt(req.getParameter("Id_team"));

                Team teamUpdated = new DaoTeam().findOne(id);
                req.setAttribute("team", teamUpdated);
                redirect = "/views/Representatives/updateTeam.jsp";
                break;

            case "/rep/equipo/equipos":
                List<Team> teams = (new DaoTeam()).findAll();
                req.setAttribute("equipos", teams);
                redirect = "/views/Representatives/RepEquipos.jsp";
                break;
            default:
                System.out.println(this.action);
        }

        req.getRequestDispatcher(this.redirect).forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html");
        System.out.println(req.getParameterMap());
        action = req.getServletPath();
        switch (action) {
            case "/equipo/delete":
                id = Integer.parseInt(req.getParameter("Id_team"));
                System.out.println("Elimina: "+ new DaoTeam().delete(id));
                if (new DaoTeam().delete(id)) {
                    redirect = "/rep/equipo/equipos?result= true&message=" + URLEncoder.encode("Equipo eliminado de forma exitosa", StandardCharsets.UTF_8);
                } else {
                    redirect = "/rep/equipo/equipos?result= false&message=" + URLEncoder.encode("Error al realizar la acción", StandardCharsets.UTF_8);
                }
                break;


            case "/equipo/save":
                System.out.println("DATOS DEL TEAM");
                System.out.println("miembros"+req.getParameter("members"));

                String name = req.getParameter("name");
                int members = Integer.parseInt(req.getParameter("members"));
                // save image
                Part filePart = req.getPart("file");

                System.out.println("DATOS DEL TEAM");
                System.out.println(name);
                System.out.println(members);
                System.out.println(file);
                String base64Image = convertToBase64(filePart);
                Team team = new Team(name, members, base64Image);


                boolean result = (new DaoTeam()).save(team);
                if (result) {
                    redirect = "/rep/equipo/equipos?result=true&message=" + URLEncoder.encode("Equipo registrado de forma exitosa", StandardCharsets.UTF_8);
                } else {
                    redirect = "/rep/equipo/create?result= false&message=" + URLEncoder.encode("Error al realizar la acción", StandardCharsets.UTF_8);
                }

                break;
            case "/equipo/update":
                int idUpdate = Integer.parseInt(req.getParameter("Id_team"));
                String nameUpdate = req.getParameter("Name_team");
                int membersUpdate = Integer.parseInt(req.getParameter("Members"));


                Part filePartUpdate = req.getPart("file");
                String base64ImageUpdate = null;
                if (filePartUpdate != null && filePartUpdate.getSize() > 0) {
                    base64ImageUpdate = convertToBase64(filePartUpdate);
                }

                Team teamToUpdate = new DaoTeam().findOne(idUpdate);
                teamToUpdate.setName(nameUpdate);
                teamToUpdate.setMembers(membersUpdate);

                if (base64ImageUpdate != null) {
                    teamToUpdate.setFile(base64ImageUpdate);
                }
                System.out.println(nameUpdate);
                System.out.println(membersUpdate);
                System.out.println(base64ImageUpdate);

                if ((new DaoTeam()).update(teamToUpdate)) {
                    resp.sendRedirect("/rep/equipo/equipos?result=true&message=" + URLEncoder.encode("Equipo actualizado correctamente", StandardCharsets.UTF_8));
                } else {
                    resp.sendRedirect("/rep/equipo/equipos?result=false&message=" + URLEncoder.encode("Error al realizar la acción", StandardCharsets.UTF_8));
                }
                return;

        }

        String var10001 = req.getContextPath();
        resp.sendRedirect(var10001 + this.redirect);
    }
    private String convertToBase64(Part filePart) throws IOException {
        InputStream inputStream = filePart.getInputStream();
        byte[] bytes = new byte[(int) filePart.getSize()];
        inputStream.read(bytes, 0, bytes.length);
        inputStream.close();
        return Base64.getEncoder().encodeToString(bytes);
    }
}



package mx.edu.utez.integradora_serif.Controllers.Matchday;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import mx.edu.utez.integradora_serif.Models.Dao.DaoMatchday;
import mx.edu.utez.integradora_serif.Models.Dao.DaoTeam;
import mx.edu.utez.integradora_serif.Models.Objetos.Matchday;
import mx.edu.utez.integradora_serif.Models.Objetos.Team;

import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.sql.Date;
import java.sql.Time;
import java.util.List;
import java.util.Optional;

@WebServlet(name = "ServletMatchday", urlPatterns = {"/matchday/matchdays", "/matchday/teams", "/matchday/admin", "/matchday/save", "/matchday/create", "/matchday/modify", "/matchday/update", "/matchday/delete",})
public class ServletMatchday extends HttpServlet {
    private String action;
    private String redirect = "/matchday/matchdays";
    Matchday matchday;
    private int id;
    private String match_field;
    private Time starthour;
    private Time endhour;
    private Date date_match;
    Team local;
    Team visit;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        this.action = req.getServletPath();
        switch (this.action) {
            case "/matchday/matchdays":
                List<Matchday> jornada = new DaoMatchday().findAll();
                req.setAttribute("jornadas", jornada);
                System.out.println("datos:" + jornada);
                redirect = "/views/Jerry/Horarios.jsp";
                break;

            case "/matchday/teams":
                List<Matchday> rank = new DaoMatchday().findAllMatchdaysWithTeams();
                req.setAttribute("rank", rank);
                System.out.println("datos=" + rank.toString());
                redirect = "/views/Jerry/RankTeams.jsp";
                break;
            case "/matchday/admin":
                List<Matchday> horarios = new DaoMatchday().findAll();
                req.setAttribute("horarios", horarios);
                redirect = "/views/Admin/Horarios_admin.jsp";
                break;

            case "/matchday/create":
                List<Team> teams = new DaoTeam().findAll();
                req.setAttribute("equipos", teams);
                redirect = "/views/Admin/Crearpartido.jsp";
                break;

            case "/matchday/modify":
                this.matchday = null;
                List<Team> equipos = new DaoTeam().findAll();
                req.setAttribute("equipos", equipos);
                this.id = Integer.parseInt(req.getParameter("Id"));
                this.matchday = (new DaoMatchday()).findOne(this.id != 0 ? Integer.parseInt(String.valueOf(this.id)) : 0);
                req.setAttribute("matchday", matchday);
                System.out.println("Entra");
                if (this.matchday != null) {
                    System.out.println(this.matchday);

                    redirect = "/views/Admin/Partidoupd.jsp";
                } else {
                    System.out.println("Activo2");
                    redirect = "/views/Admin/Horarios_admin.jsp";
                }
                break;
            default:
                System.out.println(this.action);
        }
        req.getRequestDispatcher(this.redirect).forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html");
        this.action = req.getServletPath();
        switch (this.action) {
            case "/matchday/delete":
                this.id = Integer.parseInt(req.getParameter("Id_matchday"));
                if ((new DaoMatchday()).delete(Integer.parseInt(String.valueOf(id)))) {
                    this.redirect = "/matchday/delete?result= true&message=" + URLEncoder.encode("Jornada eliminada de forma exitosa", StandardCharsets.UTF_8);
                } else {
                    this.redirect = "/matchday/delete?result= false&message=" + URLEncoder.encode("Error al realizar la acción", StandardCharsets.UTF_8);
                }
                break;
            case "/matchday/save":

                this.match_field = req.getParameter("match_field");

                String starthourStr = req.getParameter("starthour");
                if (starthourStr == null || starthourStr.isEmpty()) {
                    // Manejar error
                    this.redirect = "/matchday/save?result= false&message=" + URLEncoder.encode("Hora de inicio no proporcionada", StandardCharsets.UTF_8);
                    return;
                }
                this.starthour = Time.valueOf(starthourStr + ":00");

                String endhourStr = req.getParameter("endhour");

                if (endhourStr == null || endhourStr.isEmpty()) {
                    // Manejar error
                    this.redirect = "/matchday/save?result= false&message=" + URLEncoder.encode("Hora de fin no proporcionada", StandardCharsets.UTF_8);
                    return;
                }
                this.endhour = Time.valueOf(endhourStr + ":00");

                String dateMatchStr = req.getParameter("date_match");
                if (dateMatchStr == null || dateMatchStr.isEmpty()) {
                    // Manejar error
                    this.redirect = "/matchday/save?result= false&message=" + URLEncoder.encode("Fecha del partido no proporcionada", StandardCharsets.UTF_8);
                    return; // No continuar con el procesamiento
                }
                this.date_match = Date.valueOf(dateMatchStr);
                // get teams
                Optional<Integer> id_local = Optional.of(Integer.parseInt(req.getParameter("Id_Local")));
                Optional<Integer> id_visit = Optional.of(Integer.parseInt(req.getParameter("Id_Visit")));
                if (id_local.isEmpty()) {
                    this.redirect = "/matchday/save?result= false&message=" + URLEncoder.encode("Error al encontrar el equipo local", StandardCharsets.UTF_8);
                }
                if (id_visit.isEmpty()) {
                    this.redirect = "/matchday/save?result= false&message=" + URLEncoder.encode("Error al encontrar el equipo visitante", StandardCharsets.UTF_8);
                }
                this.local = new DaoTeam().findOne(id_local.get());
                this.visit = new DaoTeam().findOne(id_visit.get());
                this.matchday = new Matchday(0, this.match_field, this.starthour, this.endhour, this.date_match, this.local, this.visit);
                boolean result = (new DaoMatchday()).save(this.matchday);
                if (result) {
                    this.redirect = "/matchday/admin?result=true&message=" + URLEncoder.encode("Jornada registrado de forma exitosa", StandardCharsets.UTF_8);
                } else {
                    this.redirect = "/matchday/save?result= false&message=" + URLEncoder.encode("Error al realizar la acción", StandardCharsets.UTF_8);
                }
                break;
            case "/matchday/update":
                int matchId = Integer.parseInt(req.getParameter("Id"));
                this.match_field = req.getParameter("match_field");

                String starthourUpdateStr = req.getParameter("starthour");
                if (!starthourUpdateStr.contains(":") || starthourUpdateStr.isEmpty()) {
                    resp.sendRedirect("/matchday/modify?Id="+matchId+"&result=false&message=" + URLEncoder.encode("Hora de inicio no proporcionada", StandardCharsets.UTF_8));
                    return;
                }
                if (starthourUpdateStr.split(":").length == 2) {
                    starthourUpdateStr += ":00";
                }
                this.starthour = Time.valueOf(starthourUpdateStr);

                String endhourUpdateStr = req.getParameter("endhour");
                if (!endhourUpdateStr.contains(":") || endhourUpdateStr.isEmpty()) {
                    resp.sendRedirect("/matchday/modify?Id="+matchId+"&result=false&message=" + URLEncoder.encode("Hora de fin no proporcionada", StandardCharsets.UTF_8));
                    return;
                }
                if (endhourUpdateStr.split(":").length == 2) {
                    endhourUpdateStr += ":00";
                }
                this.endhour = Time.valueOf(endhourUpdateStr);

                String dateMatchUpdateStr = req.getParameter("date_match");
                if (dateMatchUpdateStr == null || dateMatchUpdateStr.isEmpty()) {
                    resp.sendRedirect("/matchday/modify?Id="+matchId+"&result=false&message=" + URLEncoder.encode("Fecha del partido no proporcionada", StandardCharsets.UTF_8));
                    return;
                }
                this.date_match = Date.valueOf(dateMatchUpdateStr);

                Optional<Integer> id_localUpdate = Optional.of(Integer.parseInt(req.getParameter("Id_Local")));
                Optional<Integer> id_visitUpdate = Optional.of(Integer.parseInt(req.getParameter("Id_Visit")));
                if (id_localUpdate.isEmpty()) {
                    resp.sendRedirect("/matchday/modify?Id="+matchId+"&result=false&message=" + URLEncoder.encode("Error al encontrar el equipo local", StandardCharsets.UTF_8));
                    return;
                }
                if (id_visitUpdate.isEmpty()) {
                    resp.sendRedirect("/matchday/modify?Id="+matchId+"&result=false&message=" +  URLEncoder.encode("Error al encontrar el equipo visitante", StandardCharsets.UTF_8));
                    return;
                }
                this.local = new DaoTeam().findOne(id_localUpdate.get());
                this.visit = new DaoTeam().findOne(id_visitUpdate.get());

                this.matchday = new Matchday(matchId, this.match_field, this.starthour, this.endhour, this.date_match, this.local, this.visit);
                boolean resultUpdate = (new DaoMatchday()).updateMatch(this.matchday, id_localUpdate.get(), id_visitUpdate.get() );
                System.out.println("TERMINO con" + resultUpdate);

                if (resultUpdate) {
                    resp.sendRedirect("/matchday/admin?result=true&message=" + URLEncoder.encode("Jornada actualizada de forma exitosa", StandardCharsets.UTF_8));

                } else {
                    resp.sendRedirect("/matchday/admin?result=true&message=" + URLEncoder.encode("Error al realizar la acción", StandardCharsets.UTF_8));
                }
                return;
        }
        String var10001 = req.getContextPath();
        resp.sendRedirect(var10001 + this.redirect);
    }
}

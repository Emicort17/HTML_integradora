package mx.edu.utez.integradora_serif.Models.Dao;

import mx.edu.utez.integradora_serif.Models.Objetos.Matchday;

import java.util.List;
public interface DaoRepository<T> {
    List<T> findAll();
    T findOne(int id);
    boolean save(T object);
    boolean update(T object);
    boolean delete(int id);

}